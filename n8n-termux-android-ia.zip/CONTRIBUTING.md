# Contribuir

1. Crea un fork y una rama: `git checkout -b feat/mi-mejora`
2. Haz cambios y añade pruebas si aplica.
3. Ejecuta scripts localmente en un dispositivo Android real con Termux.
4. Crea un Pull Request describiendo el cambio y resultados.

> Dudas y issues: usa la pestaña **Issues**.
