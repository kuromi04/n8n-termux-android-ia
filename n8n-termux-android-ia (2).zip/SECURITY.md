# Seguridad

- No publiques tus claves o tokens en este repo.
- Si encuentras una vulnerabilidad, abre un Issue con detalles **sin** exponer credenciales.
